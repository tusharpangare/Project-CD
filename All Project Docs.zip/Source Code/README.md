# Crop-Prediction-Django
Prediction of suitable crop using soil and weather conditions.
